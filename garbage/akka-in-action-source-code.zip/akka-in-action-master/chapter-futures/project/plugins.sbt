resolvers += Classpaths.typesafeResolver
